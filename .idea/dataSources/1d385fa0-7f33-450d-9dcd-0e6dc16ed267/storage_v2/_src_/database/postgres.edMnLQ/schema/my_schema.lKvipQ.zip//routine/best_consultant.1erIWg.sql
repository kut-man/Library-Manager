create function best_consultant() returns character varying
    language plpgsql
as
$$
DECLARE
		consultant VARCHAR;
	BEGIN
		SELECT service_consultant_name, 
		COUNT(*) INTO consultant FROM my_schema.customers_purchases 
		GROUP BY service_consultant_name ORDER BY COUNT(*) DESC LIMIT 1;
		RETURN consultant;
	END;

$$;

alter function best_consultant() owner to postgres;

