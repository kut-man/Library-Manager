create function gun_comparison5() returns character varying
    language plpgsql
as
$$
DECLARE
		popular_gun_sold INT;
		pupular_gun_name VARCHAR(50);
	BEGIN
		SELECT gun_id, COUNT(*) INTO popular_gun_sold FROM my_schema.customers_purchases 
		GROUP BY gun_id ORDER BY COUNT(*) DESC LIMIT 1;
		SELECT gun_name INTO pupular_gun_name FROM my_schema.guns WHERE id = popular_gun_sold;
		RETURN pupular_gun_name;
	END;

$$;

alter function gun_comparison5() owner to postgres;

