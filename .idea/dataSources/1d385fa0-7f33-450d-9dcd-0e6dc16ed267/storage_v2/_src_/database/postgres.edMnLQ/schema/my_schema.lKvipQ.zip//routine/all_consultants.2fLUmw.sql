create function all_consultants() returns integer
    language plpgsql
as
$$
DECLARE
	quantity INT;
	BEGIN
		SELECT COUNT(first_name) INTO quantity FROM my_schema.consultants;
		RETURN quantity;
	END;

$$;

alter function all_consultants() owner to postgres;

