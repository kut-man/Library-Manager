create view customers_reviews_consultants(username, review_content, service_consultant_name) as
SELECT customers.username,
       suggestions_reviews.review_content,
       suggestions_reviews.service_consultant_name
FROM my_schema.customers
         JOIN my_schema.suggestions_reviews ON customers.id = suggestions_reviews.customer_id;

alter table customers_reviews_consultants
    owner to postgres;

