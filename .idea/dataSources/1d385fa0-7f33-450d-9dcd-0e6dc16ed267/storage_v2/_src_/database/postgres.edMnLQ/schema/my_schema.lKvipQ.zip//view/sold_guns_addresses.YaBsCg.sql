create view sold_guns_addresses(customer_id, username, gun_name, id, addresses) as
SELECT customers_purchases.customer_id,
       customers.username,
       guns.gun_name,
       guns.id,
       customers.addresses
FROM my_schema.customers_purchases
         JOIN my_schema.guns ON guns.id = customers_purchases.gun_id
         JOIN my_schema.customers ON customers.id = customers_purchases.customer_id
ORDER BY customers_purchases.customer_id;

alter table sold_guns_addresses
    owner to postgres;

