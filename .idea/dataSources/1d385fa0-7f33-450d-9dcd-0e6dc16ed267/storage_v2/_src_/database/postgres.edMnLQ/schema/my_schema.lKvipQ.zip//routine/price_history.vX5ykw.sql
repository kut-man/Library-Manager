create function price_history() returns trigger
    language plpgsql
as
$$
BEGIN
	INSERT INTO my_schema.statistics(changed_date, price) VALUES (NOW(), OLD.price);
	RETURN NEW;
END;
$$;

alter function price_history() owner to postgres;

