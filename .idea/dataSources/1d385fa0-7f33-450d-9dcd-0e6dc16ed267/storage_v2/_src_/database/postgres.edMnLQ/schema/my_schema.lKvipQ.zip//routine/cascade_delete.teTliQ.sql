create function cascade_delete() returns trigger
    language plpgsql
as
$$
BEGIN
	DELETE FROM my_schema.suggestions_reviews WHERE service_consultant_name = OLD.first_name;
	DELETE FROM my_schema.customers_purchases WHERE service_consultant_name = OLD.first_name;
	RETURN OLD;
END;

$$;

alter function cascade_delete() owner to postgres;

