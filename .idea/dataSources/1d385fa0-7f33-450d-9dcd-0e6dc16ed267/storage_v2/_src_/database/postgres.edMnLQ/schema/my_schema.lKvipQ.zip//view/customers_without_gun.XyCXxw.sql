create view customers_without_gun(customer_id, username, gun_name) as
SELECT customers_purchases.customer_id,
       customers.username,
       guns.gun_name
FROM my_schema.customers_purchases
         JOIN my_schema.guns ON guns.id = customers_purchases.gun_id
         RIGHT JOIN my_schema.customers ON customers.id = customers_purchases.customer_id
WHERE customers_purchases.customer_id IS NULL
ORDER BY customers_purchases.customer_id;

alter table customers_without_gun
    owner to postgres;

