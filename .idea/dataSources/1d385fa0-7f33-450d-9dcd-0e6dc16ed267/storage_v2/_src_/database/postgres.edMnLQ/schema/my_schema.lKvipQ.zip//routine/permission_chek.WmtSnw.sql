create function permission_chek() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.permission = 'false') THEN
		RAISE NOTICE USING MESSAGE = 'You need Permission to buy a gun!!!';
		RETURN NEW;
	END IF;
END;
$$;

alter function permission_chek() owner to postgres;

