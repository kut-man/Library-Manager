create view served_consultants(customer_id, username, gun_name, service_consultant_name) as
SELECT customers_purchases.customer_id,
       customers.username,
       guns.gun_name,
       customers_purchases.service_consultant_name
FROM my_schema.customers_purchases
         JOIN my_schema.guns ON guns.id = customers_purchases.gun_id
         JOIN my_schema.customers ON customers.id = customers_purchases.customer_id
ORDER BY customers_purchases.customer_id;

alter table served_consultants
    owner to postgres;

