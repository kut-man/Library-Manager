create function gun_comparison(gun1 integer, gun2 integer) returns integer
    language plpgsql
as
$$
DECLARE
		popular_gun_sold INT;
	BEGIN
		SELECT gun_id, COUNT(*) INTO popular_gun_sold FROM my_schema.customers_purchases 
		GROUP BY gun_id HAVING gun_id = gun1 OR gun_id = gun2 ORDER BY COUNT(*) DESC LIMIT 1;
		RETURN popular_gun_sold;
	END;

$$;

alter function gun_comparison(integer, integer) owner to postgres;

