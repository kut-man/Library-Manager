create function best_consultant_service_quantity() returns integer
    language plpgsql
as
$$
DECLARE
		max_num INT;
	BEGIN
		SELECT MAX (mycount) INTO max_num
		FROM (SELECT service_consultant_name, 
		COUNT(*) AS mycount FROM my_schema.customers_purchases 
		GROUP BY service_consultant_name) AS service_count;
		RETURN max_num;
	END;

$$;

alter function best_consultant_service_quantity() owner to postgres;

