create view info (customer_id, gun_id, service_consultant_name, purchased_date, id, username, permission, addresses) as
SELECT customers_purchases.customer_id,
       customers_purchases.gun_id,
       customers_purchases.service_consultant_name,
       customers_purchases.purchased_date,
       fo.id,
       fo.username,
       fo.permission,
       fo.addresses
FROM my_schema.customers_purchases
         RIGHT JOIN (SELECT customers.id,
                            customers.username,
                            customers.permission,
                            customers.addresses
                     FROM my_schema.customers) fo ON fo.id = customers_purchases.customer_id
ORDER BY fo.id;

alter table info
    owner to postgres;

